﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace GalleryApp
{
    public partial class MainShell
    {
        public MainShell()
        {
            InitializeComponent();
        }
    }
}
