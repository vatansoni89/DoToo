﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WhackABox
{
    public class GameStats
    {
        public int NumberOfPlanes { get; set; }
        public int NumberOfBoxes { get; set; }
    }
}
