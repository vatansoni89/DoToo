﻿using Xamarin.Forms;

namespace WhackABox.Controls
{
    public class ARView : View
    {
    }
}