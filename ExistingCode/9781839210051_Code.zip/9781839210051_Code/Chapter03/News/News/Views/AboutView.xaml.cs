﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace News.Views
{
    public partial class AboutView : ContentPage
    {
        public AboutView()
        {
            InitializeComponent();
        }
    }
}
