﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace News.Views
{
    public partial class ArticleItem : ContentView
    {
        public ArticleItem()
        {
            InitializeComponent();
        }
    }
}
