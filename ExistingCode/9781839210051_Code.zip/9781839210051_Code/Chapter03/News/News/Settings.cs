﻿using System;
namespace News
{
    public static class Settings
    {
        public static string NewsApiKey
        {
            get
            {
                // todo remove before push to Packt
                return "142b30001ea949fa8cb10e0f7cb4c463";
            }
        }
    }
}
