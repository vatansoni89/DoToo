﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MeTracker.Services
{
    public interface ILocationTrackingService
    {
        void StartTracking();
    }
}
